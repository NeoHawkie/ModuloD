<?php

//chama a function.php
require 'functions.php';
require 'models/Livro.php';
require 'dados.php';
require "routes.php";









?>

